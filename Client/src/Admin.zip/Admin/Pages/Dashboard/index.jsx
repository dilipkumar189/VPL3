import React from 'react';
import Sidebar from "../../Layouts/Sidebar";
import Header from '../../Layouts/Header';

export default function Dashboard() {
  return (
    <>
      <div className="">
        <Sidebar />
        <Header />

      </div>
    </>
  );
}
